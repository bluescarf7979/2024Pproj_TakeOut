"""road_monitoring_project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from django.conf.urls.static import static
from django.conf import settings

schema_view = get_schema_view(
    openapi.Info(
        title="API Documentation",         # API 문서 제목
        default_version='v1',              # API 버전
        description="API documentation for our application",  # 설명
        terms_of_service="https://www.example.com/terms/",
        contact=openapi.Contact(email="support@example.com"),  # 연락처
        license=openapi.License(name="MIT License"),           # 라이선스
    ),
    public=True,  # 공개 여부 (True로 설정하면 누구나 접근 가능)
    permission_classes=(AllowAny,),  # 문서 접근 권한
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/user/', include('users.urls')),
    path('api/road_info/', include('road_info.urls')),
    # path('api/posts/', include('posts.urls')),
    # path('api/notifications/', include('notifications.urls')),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # 로그인
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # 토큰 갱신

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)